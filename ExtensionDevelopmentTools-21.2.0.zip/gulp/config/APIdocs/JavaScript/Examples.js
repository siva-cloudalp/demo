// Instantiate the LoginRegisterPage component
var loginRegisterPageComponent  = container.getComponent("LoginRegisterPage");

if (loginRegisterPageComponent ) {
    // 
    loginRegisterPageComponent.on('beforeLogin', function () {

    });
}
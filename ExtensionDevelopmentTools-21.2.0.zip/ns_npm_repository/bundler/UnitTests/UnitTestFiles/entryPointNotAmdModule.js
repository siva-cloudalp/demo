console.log('notAmdModule');

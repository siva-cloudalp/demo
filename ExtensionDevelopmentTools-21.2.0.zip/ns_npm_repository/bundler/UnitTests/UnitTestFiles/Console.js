define('Console', [], function() {});

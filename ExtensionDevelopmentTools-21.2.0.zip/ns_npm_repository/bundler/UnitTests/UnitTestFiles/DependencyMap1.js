define('DependencyMap1', function() {});

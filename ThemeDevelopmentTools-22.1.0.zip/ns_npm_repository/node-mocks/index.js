module.exports = {
    mockChild_process: require('./modules/child_processMock'),
    mockCrypto: require('./modules/cryptoMock'),
    mockNsServer: require('./modules/nsServerMock'),
    mockFs: require('./modules/fsMock'),
    mockHttp: require('./modules/httpMock'),
    mockHttps: require('./modules/httpsMock'),
    mockOs: require('./modules/osMock'),
    mockPath: require('./modules/pathMock'),
    mockQuerystring: require('./modules/querystringMock'),
    mockUrl: require('./modules/urlMock')
}

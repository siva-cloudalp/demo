/* eslint-disable */


define

('EntryPoint2',




    ["Dependency1"],


    function() {});


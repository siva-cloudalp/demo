define('EntryPointMap2', ['DependencyMap4'], function() {});

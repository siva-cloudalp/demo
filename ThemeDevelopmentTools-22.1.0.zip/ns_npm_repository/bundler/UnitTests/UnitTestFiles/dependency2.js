define('Dependency2', ['Dependency3'], function() {});

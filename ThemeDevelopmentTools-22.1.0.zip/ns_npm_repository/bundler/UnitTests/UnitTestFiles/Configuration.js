define('Configuration', ['Utils','SC.Models.Init', 'Console'], function())
